#ifndef _AFOC_H_
#define _AFOC_H_

#include "stm32g4xx_hal.h"

#define _constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))
#define PI 3.1415926f

void Motor_Test(int tim,int sss);
void Motor_Test2(int tim,int sss);
float _normalizeAngle(float angle);
void setPwm(float Ua, float Ub, float Uc);
void setPhaseVoltage(float Uq,float Ud, float angle_el);

//void FOC_Init(void);

#endif
