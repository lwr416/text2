#ifndef _FOC_H_
#define _FOC_H_

#include "stm32g4xx_hal.h"

void setPhaseVoltage(float Uq,float Ud, float angle_el);
float _electricalAngle();

#endif

