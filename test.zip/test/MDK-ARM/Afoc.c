#include "bsp_as5600.h"
#include "tim.h"
#include "Afoc.h"
#include <math.h> 
 
float voltage_limit=12.6;
float voltage_power_supply=12.6;
float shaft_angle=0,open_loop_timestamp=0;
float Ualpha,Ubeta=0,Ua=0,Ub=0,Uc=0,dc_a=0,dc_b=0,dc_c=0;
int PP=7,DIR=-1;

#define xianzhi 65536
#define _3PI_2  4.71238898038f 
 
 
void Motor_Test(int tim,int sss)
{
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, sss);
		HAL_Delay(tim);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, sss);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, sss);
		HAL_Delay(tim);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, sss);
		HAL_Delay(tim);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, sss);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, sss);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, 0);
		HAL_Delay(tim);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, sss);
		HAL_Delay(tim);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, sss);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, sss);
		HAL_Delay(tim);
}
void Motor_Test2(int tim,int sss)
{
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, sss);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, sss);
		HAL_Delay(tim);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, sss);
		HAL_Delay(tim);
			__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, sss);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, sss);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, 0);
		HAL_Delay(tim);
			__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, sss);
		HAL_Delay(tim);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, sss);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, sss);
		HAL_Delay(tim);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, 0);
		__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, sss);
		HAL_Delay(tim);





}

// ��һ���Ƕȵ� [0,2PI]
float _normalizeAngle(float angle){
  float a = fmod(angle, 2*PI);   //ȡ������������ڹ�һ�����г�����ֵ�������֪
  return a >= 0 ? a : (a + 2*PI);
}
 
 
// ����PWM�����������
void setPwm(float Ua, float Ub, float Uc) {
 
  // ��������
  Ua = _constrain(Ua, 0.0f, voltage_limit);
  Ub = _constrain(Ub, 0.0f, voltage_limit);
  Uc = _constrain(Uc, 0.0f, voltage_limit);
  // ����ռ�ձ�
  // ����ռ�ձȴ�0��1
  dc_a = _constrain(Ua / voltage_power_supply, 0.0f , 1.0f );
  dc_b = _constrain(Ub / voltage_power_supply, 0.0f , 1.0f );
  dc_c = _constrain(Uc / voltage_power_supply, 0.0f , 1.0f );
 
  //д��PWM��PWM 0 1 2 ͨ��
	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, dc_a*xianzhi);
	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2, dc_b*xianzhi);
	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3, dc_c*xianzhi);
}
 
void setPhaseVoltage(float Uq,float Ud, float angle_el) {
  angle_el = _normalizeAngle(angle_el);
  // ������任
  Ualpha =  -Uq*sin(angle_el);
  Ubeta =   Uq*cos(angle_el);
 
  // ��������任
  Ua = Ualpha + voltage_power_supply/2;
  Ub = (sqrt(3)*Ubeta-Ualpha)/2 + voltage_power_supply/2;
  Uc = (-Ualpha-sqrt(3)*Ubeta)/2 + voltage_power_supply/2;
  setPwm(Ub,Ua,Uc);
}
 
 
 
